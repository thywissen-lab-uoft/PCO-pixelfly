function [error_code] = pf_camera_open_close(board_number)
% open and close the camera SDK
%
% [error_code] = pf_camera_open_close(board_number)
%
% * Input parameters :
%    board_number               number of board to use [0...7] default 0
% * Output parameters :
%    error_code                 returned error_code from SDK-functions 
%
% global glvar
% see init_glvar for more information for global structure glvar
%
% if global glvar is not initialized,
% the library is loaded at begin and unloaded at end
% the SDK is opened at begin and closed at end
%
% function workflow
% load library if not already loaded
% camera SDK is opened
% camera SDK is closed
% library is unloaded
%

% 2014 September - MBL PCO AG

 global glvar;

 [fh_prog_exit,fh_prog_init,fh_com_disp]=pf_misc_func();


 if(nargin<1)
  board_number=0;
 end 
 
 [do_unload,do_close,cam_open,board_handle,ret_bufnr,comment]=fh_prog_init(board_number);

%libcall pfINITBOARD does load library if not already loaded
 if(cam_open==0)
  fh_com_disp(comment,['call pfINITBOARD(',int2str(board_number),') open driver and initialize camera']);
  [error_code,board_handle] = pfINITBOARD(board_number);
  if(error_code~=0) 
   pco_errdisp('pfINITBOARD',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   return;
  end 
  cam_open=1;
  fh_com_disp(comment,['Camera ',int2str(board_number),' opened']);
  
  if(~isempty(glvar))
   bnr=board_number+1;   
   if((isfield(glvar.boardpar(bnr),'camera_open'))&& ...
      (isfield(glvar.boardpar(bnr),'board_handle')))
    glvar.boardpar(bnr).camera_open=cam_open;
    glvar.boardpar(bnr).board_handle=board_handle; 
   end 
  end 
 end

%does close and unload 
 fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);

end


