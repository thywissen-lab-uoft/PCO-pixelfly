function [error_code,ima] = get_pic16(board_number,waittime_ms)
% grab single image with ADD_BUFFER,WAIT_FOR_BUFFER function.
%
% [error_code,image] = get_pic16(board_number);
%
% get_pic16 does grab one image from the camera using actual settings
% camera is started if not already running
% using allocate and wait functions from library
% image is then displayed in image window, if no output variable is given
%
% * Input parameters :
%    board_number               number of board to use [0...7] default 0
% * Output parameters :
%    error_code                 returned error_code from SDK-functions 
%    ima                        image data
%                               if not avaiable image is displayed
%
% global glvar
% see glvar_init for more information for global structure glvar
%
% if global glvar is not initialized,
% the library is loaded at begin and unloaded at end
% the SDK is opened at begin and closed at end
%
% function workflow
% load library if not already loaded
% camera SDK is opened if not already open
% image buffer is allocated
% camera recording is started if necessary
% grab image to image buffer
% camera is stopped if internal started 
% camera SDK is closed
% library is unloaded
% image buffer is displayed or returned

% 2008 June - MBL PCO AG
% 2012 November - new pf_cam SDK (64Bit) MBL PCO AG
% 2014 September - with glvar MBL PCO AG

 global glvar;

 pf_load_defines;
 
 [fh_prog_exit,fh_prog_init,fh_com_disp]=pf_misc_func();

 if(nargin<1)
  board_number=0;
 end 
 
 if(nargin<2)
  waittime_ms=1000;
 end 
  
 if(~exist('show_ima','var'))
  if(nargout<2)
   show_ima=1;   
  else 
   show_ima=0;   
   ima=0;   
  end 
 end 

 [do_unload,do_close,cam_open,board_handle,ret_bufnr,comment]=fh_prog_init(board_number);

%try to initialize camera
 if(cam_open==0)
  fh_com_disp(comment,['call pfINITBOARD(',int2str(board_number),') open driver and initialize camera']);
  [error_code,board_handle] = pfINITBOARD(board_number);
  if(error_code~=0) 
   pco_errdisp('pfINITBOARD',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   return;
  end 
  fh_com_disp(comment,['Camera ',int2str(board_number),' opened']);
 end
 
 
 cam_open=1;
 bnr=board_number+1;   
 if(~isempty(glvar))
  if((isfield(glvar.boardpar(bnr),'camera_open'))&& ...
    (isfield(glvar.boardpar(bnr),'board_handle')))
   glvar.boardpar(bnr).camera_open=cam_open;
   glvar.boardpar(bnr).board_handle=board_handle; 
  end 
 end 
 
 fh_com_disp(comment,'call pfGETSIZES, to get actual resolution of the camera');

 [error_code,~,~,act_width,act_height,bit_pix]=pfGETSIZES(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfGETSIZES',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end

 %get the memory for the image
 imasize=act_width*act_height*floor((bit_pix+7)/8);

 fh_com_disp(comment,['image size in bytes is: ',int2str(imasize)]); 
 fh_com_disp(comment,'allocate data array (image_stack) for the image');
 
 image_stack=ones(act_width,act_height,'uint16');
 ima_ptr = libpointer('uint16Ptr',image_stack);

 fh_com_disp(comment,'call pfALLOCATE_BUFFER_EX, to assign a buffer number to allocated image_stack');
 bufnr=ret_bufnr;
 fh_com_disp(comment,['bufnr is ',int2str(bufnr)]);
 [error_code, ret_bufnr] = pfALLOCATE_BUFFER_EX(board_handle, bufnr,imasize,ima_ptr);
 if(error_code~=0) 
  pco_errdisp('pfALLOCATE_BUFFER_EX',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,['Buffer number ',int2str(ret_bufnr),' assigned to allocated image_stack']);
 if(~isempty(glvar))
  if(isfield(glvar.boardpar(bnr),'buf_numbers'))
   glvar.boardpar(bnr).buf_numbers=ret_bufnr;
  end
 end 

 fh_com_disp(comment,'call pfADD_BUFFER_TO_LIST, to add buffer to the SDK buffer queue');
 error_code=pfADD_BUFFER_TO_LIST(board_handle,ret_bufnr,imasize);
 if(error_code~=0) 
  pco_errdisp('pfADD_BUFFER_TO_LIST',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,['Buffer number ',int2str(ret_bufnr),' added to SDK buffer queue']);

 
 run=0;
 [error_code, value] = pfGETBOARDVAL(board_handle,'PCC_VAL_BOARD_STATUS');
 if(error_code)
  pco_errdisp('pfGETBOARDVAL',error_code);   
 else
  if(bitand(value,hex2dec('01'))~=hex2dec('01'))
   fh_com_disp(comment,'Camera is not running call START_CAMERA')     
   error_code=pfSTART_CAMERA(board_handle);
   if(error_code~=0) 
    pco_errdisp('pfSTART_CAMERA',error_code);
    fh_com_disp(comment,'Camera started');
   end 
   run=1;
  end 
 end
 
 error_code=pfTRIGGER_CAMERA(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfTRIGGER_CAMERA',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,'Camera triggered');

 [error_code,image_status] = pfGETBUFFER_STATUS(board_handle,ret_bufnr,0,4);
 if(error_code~=0) 
  pco_errdisp('pfGETBUFFER_STATUS',error_code);
 else
  fh_com_disp(comment,['image status is ',num2str(pco_uint32(image_status),'%08X')]);
 end

 fh_com_disp(comment,'call pfWAIT_FOR_BUFFERS, to wait until image is grabbed into buffer');
 [error_code,ima_bufnr]=pfWAIT_FOR_BUFFERS(board_handle,waittime_ms,ret_bufnr);
 if(error_code~=0) 
  pco_errdisp('pfWAIT_FOR_BUFFERS',error_code);
 else
  fh_com_disp(comment,['image grabbed to buffer ',int2str(ima_bufnr)]);
 end

 [error_code,image_status] = pfGETBUFFER_STATUS(board_handle,ret_bufnr,0,4);
 if(error_code~=0) 
  pco_errdisp('pfGETBUFFER_STATUS',error_code);
 else
  fh_com_disp(comment,['buffer status is ',num2str(pco_uint32(image_status),'%08X')]);
 end

 image_status=bitand(pco_uint32(image_status),hex2dec('F10F'));
 fh_com_disp(comment,['bitand buffer status is ',num2str(image_status)]);
 
 if((ima_bufnr<0)||(image_status~=hex2dec('0002')))
  error_code=PCO_ERROR_APPLICATION+PCO_ERROR_WRONGVALUE;   
  fh_com_disp(comment,'error: image not successfully grabbed');
  e=pfREMOVE_BUFFER_FROM_LIST(board_handle,ret_bufnr);
  pco_errdisp('pfREMOVE_BUFFER_FROM_LIST',e);
 end

 if(run==1)
  fh_com_disp(comment,'Camera is has been started call STOP_CAMERA')     
  e=pfSTOP_CAMERA(board_handle);
  if(e~=0) 
   pco_errdisp('pfSTOP_CAMERA',e);
   fh_com_disp(comment,'Camera stopped');
  end 
 end

 fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);

 if(error_code~=0)
  ima=0;
  return;
 end 
     
 image_stack=get(ima_ptr,'Value');
 ima=image_stack';
 if(comment)
  m=max(max(ima(10:end-10,10:end-10)));
  disp(['maximum value in center of image is ',num2str(m)]);
 end 
 if(show_ima)
  m=max(max(ima(10:end-10,10:end-10)));
%  imshow(ima,[0,m+100]);
  draw_image(ima,[0 m+100]);
  disp('Press "Enter" to close window and proceed')
  pause();
  close();
  pause(1);
  clear ima;
 end 
end
  

