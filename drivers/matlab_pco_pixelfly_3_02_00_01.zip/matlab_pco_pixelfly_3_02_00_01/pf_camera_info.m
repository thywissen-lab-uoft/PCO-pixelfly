function pf_camera_info()
% display some information of all connected cameras 
%
% camera_info()
%
% * Input parameters :
%
% * Output parameters :
%
%
% function workflow
% load library 
% camera SDK is opened
% readout camera information 
% camera SDK is closed
% library is unloaded
%
% 2008 June -  MBL PCO AG
% 2012 November - new pf_cam SDK (64Bit) MBL PCO AG
% 2014 September - new library headers included MBL PCO AG

 
 if(strcmp(computer('arch'),'win32'))
  if(~exist('./pf_cam.dll','file'))
   copyfile('./win32/pf_cam.dll','./');
  end 
 elseif(strcmp(computer('arch'),'win64'))
  if(~exist('./pf_cam.dll','file'))
   copyfile('./x64/pf_cam.dll','./');
  end 
 else
  error('This platform is not supported');   
 end 
 
%load the (error) defines 
 pf_load_defines

 global glvar;

 if(~isempty(glvar))
  error('...please use this function only, when glvar is not initialized!')
 end 
  
 if not(libisloaded('PCO_PF_SDK'))
  loadlibrary('pf_cam','pf_Matlab.h' ...
              ,'addheader','PfcamExport.h' ...
              ,'addheader','pcc_ML_struct.h' ...
              ,'alias','PCO_PF_SDK');
  disp('external library pf_cam loaded');
 end

 for n=1:4
  board_number = int32(n-1);
  disp(['call pfINITBOARD(',int2str(board_number),')']);
  [error_code,board_handle]=pfINITBOARD(board_number);
  pco_errdisp('pfINITBOARD',error_code);
  e=pco_uint32err(error_code);
  if((bitand(e,(hex2dec('0F000FFFF'))))==PCO_ERROR_DRIVER_HEAD_LOST)    
   init=2;
  elseif(error_code~=0) 
   disp('no more cameras connected');
   break;
  else
   init=1;   
  end 
  
  if(init==2)
   disp('Camera head not connected');
  else
   disp(['Camera connected to board ',int2str(board_number)]);

   [error_code, value] = pfGETBOARDVAL(board_handle,'PCC_VAL_CCDTYPE');
   if(error_code)
    pco_errdisp('pfGETBOARDVAL',error_code);   
   else
    if(bitand(value,hex2dec('01'))==hex2dec('01'))
     disp('Camera Head has a Color CCD')     
    else 
     disp('Camera Head has a BW CCD')     
    end 
   end
 
   [error_code, value] = pfGETBOARDVAL(board_handle,'PCC_VAL_EXTMODE');
   if(error_code)
    pco_errdisp('pfGETBOARDVAL',error_code);   
   else
    if(bitand(value,hex2dec('01'))~=0)
     disp('Camera Head has DOUBLE feature')     
    end 
    if(bitand(value,hex2dec('FF00'))~=0)
     disp('Camera Head has PRISMA feature')     
    end
    if(bitand(value,hex2dec('010000'))~=0)
     disp('Camera Head has LOGLUT feature')     
    end
   end
  
   [error_code,ccd_width,ccd_height,image_width,image_height]=pfGETSIZES(board_handle);
   if(error_code)
    pco_errdisp('pfGETSIZES',error_code);   
   else
    disp(['Max. Resolution is: ', int2str(ccd_width), 'x' int2str(ccd_height)]);
    disp(['Act. Resolution is: ', int2str(image_width), 'x' int2str(image_height)]);
   end 
  end
  
  disp(' ');
  
%read HEAD version     
  text=blanks(100);
  [error_code,~, text]= calllib('PCO_PF_SDK','READVERSION',board_handle,5,text,100);
  if(error_code)
   pco_errdisp('READVERSION',error_code);   
  else
   disp(strtrim(text));   
  end  
  clear(text);

%read HW version     
  text=blanks(100);
  [error_code,~, text]= calllib('PCO_PF_SDK','READVERSION',board_handle,4,text,100);
  if(error_code)
   pco_errdisp('READVERSION',error_code);   
  else
   disp(strtrim(text));   
  end  
  clear(text);
 
%read CPLD version     
  text=blanks(100);
  [error_code,~, text]= calllib('PCO_PF_SDK','READVERSION',board_handle,6,text,100);
  if(error_code)
   pco_errdisp('READVERSION',error_code);   
  else
   disp(strtrim(text));   
  end  
  clear(text);
 
%read PLUTO version     
  text=blanks(100);
  [error_code,~, text]= calllib('PCO_PF_SDK','READVERSION',board_handle,1,text,100);
  if(error_code)
   pco_errdisp('READVERSION',error_code);   
  else
   disp(strtrim(text));   
  end  
  clear(text);
 
%read CIRCE version     
  text=blanks(100);
  [error_code,~, text]= calllib('PCO_PF_SDK','READVERSION',board_handle,2,text,100);
  if(error_code)
   pco_errdisp('READVERSION',error_code);   
  else
   disp(strtrim(text));   
  end  
  clear(text);
 
%read ORION version     
  text=blanks(100);
  [error_code,~, text]= calllib('PCO_PF_SDK','READVERSION',board_handle,3,text,100);
  if(error_code)
   pco_errdisp('READVERSION',error_code);   
  else
   disp(strtrim(text));   
  end  
  clear(text);
 
 text=blanks(100);
 text1=blanks(100);
 [error_code,~, text,text1]= calllib('PCO_PF_SDK','PCC_GET_VERSION',board_handle,text,text1);
  if(error_code)
   pco_errdisp('PCC_GET_VERSION',error_code);   
  else
   disp(['DLL Version: ',text]);   
   disp(['SYS Version: ',text1]);
  end  
  clear(text);
  clear(text1);
   
  [error_code] = pfCLOSEBOARD(board_handle); 
  if(error_code)
   pco_errdisp('pfCLOSEBOARD',error_code);   
  else
   disp(['camera ',int2str(board_number),' closed']);     
  end 
  disp(' '); 
 end

 if(libisloaded('PCO_PF_SDK'))
  unloadlibrary('PCO_PF_SDK');
  disp('external library pf_cam unloaded');
 end 
end   
 
