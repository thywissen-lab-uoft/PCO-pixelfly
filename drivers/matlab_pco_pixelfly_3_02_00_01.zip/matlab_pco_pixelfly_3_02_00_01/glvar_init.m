function glvar_init()
%
%   glvar_init();
%
% initializes a global glvar structure, which can be used to control the
% behaviour of the other m-functions
%
%	* Input parameters :
%
%	* Output parameters :
%
%structure glvar is used to select camera and to set different modes for
%load/unload library
%open/close camera SDK
%The structure does also hold additional information for each camera
%
%glvar.do_libunload: 1=unload lib at end
%glvar.comment:      display messages during program flow (0,1)
%                    error messages are always displayed
%glvar.boardpar():   parameters for each board
%glvar.boardpar().do_close:     1=close camera SDK at end
%glvar.boardpar().camera_open:  open status of camera SDK (0,1)
%glvar.boardpar().board_handle: libpointer to camera SDK handle
%glvar.boardpar().buf_numbers:  array of allocated buffers

global glvar;
 
 glvar.do_libunload=1;
 glvar.comment=1;

 for n=1:8
  glvar.boardpar(n).do_close=1;
  glvar.boardpar(n).camera_open=0;
  glvar.boardpar(n).board_handle=[];
  glvar.boardpar(n).buf_numbers=-1;
 end
end
