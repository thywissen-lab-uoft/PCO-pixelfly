function [error_code,ret_bufnr,evh,bufadr] = ...
                      pfALLOCATE_BUFFER_EX(board_handle, bufnr, bufsize,ima_ptr)
% pfALLOCATE_BUFFER_EX assign or allocate memory
%
%[error_code, ret_bufnr] = pfALLOCATE_BUFFER_EX(board_handle, bufnr, bufsize,ima_ptr)
%
% pfALLOCATE_BUFFER_EX does assign a buffer number to a external allocated buffer
% i.E. one of the buffers in an imagestack.
% The value of bufsize has to be set to the number of bytes which have been
% allocated for one image.
% To assign a new buffer number, the value of bufnr has to be set to: -1.
% The return value ret_bufnr can be used in the calls to other functions
% with buf_nr as input parameter. 
% If the function fails, the return values ret_bufnr and ret_bufsize
% are not valid and must not be used
% or
% if called with nargin==3 (without im_ptr)
% pfALLOCATE_BUFFER_EX does allocate a internal memory with bufsize Bytes and 
% does return the address of this buffer
%
% * Input parameters :
%    board_handle [libpointer]  board_handle from INITBOARD
%    bufnr [int32]              buffer number to be allocated
%                               => -1 for a new buffer
%    bufsize [int32]            size of buffer, which should be allocated
%    ima_ptr [libpointer]       pointer to MATLAB array
% * Output parameters :
%    error_code [int32]         zero on success, nonzero indicates failure
%                               returned value is the SDK errorcode
%    ret_bufnr [int32]          number of buffer, which has been
%                               allocated or assigned
%    bufadr [libpointer]        address of allocated buffer            

% revision history:
% 2012 November - new pf_cam SDK (64Bit) MBL PCO AG
% 2014 September - description changed
%                  SDK memory allocation implemented MBL PCO AG

% check if library has been already loaded
if not(libisloaded('PCO_PF_SDK'))
 error('library must have been loaded with pfINITBOARD')
end

if nargin < 3
 error('...wrong number of arguments have been passed to pfALLOCATE_BUFFER_EX, see help!')
end

bufnr_ptr = libpointer('int32Ptr', bufnr);
ev_ptr=libpointer('voidPtrPtr');

if(nargin==4)
 [error_code] = calllib('PCO_PF_SDK', 'ALLOCATE_BUFFER_EX',board_handle,bufnr_ptr, bufsize,ev_ptr,ima_ptr);
 bufadr=ima_ptr;
 ret_bufnr = int32(get(bufnr_ptr, 'Value'));
 evh=get(ev_ptr,'Value');
 if(error_code~=0)
  ret_bufnr=-1;
  return;
 end 
else 
 buf_ptr=libpointer('voidPtrPtr');
 [error_code] = ...
  calllib('PCO_PF_SDK', 'ALLOCATE_BUFFER_EX',board_handle,bufnr_ptr, bufsize,ev_ptr,buf_ptr);
 if(error_code~=0)
  ret_bufnr=-1;
  return;
 end 
 
 bufadr=get(buf_ptr,'Value');
 ret_bufnr = int32(get(bufnr_ptr, 'Value'));
 evh=get(ev_ptr,'Value');
end
end
