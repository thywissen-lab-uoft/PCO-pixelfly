function [error_code] = pfCLOSEBOARD(board_handle)
% pfCLOSEBOARD close the driver.
%
% [error_code] = pfCLOSEBOARD(board_number);
% pfCLOSEBOARD resets the PCI-Controller-Board and closes the driver.
% see also pixelfly SDK manual 
%
% * Input parameters :
%    board_handle [libpointer]  board_handle from INITBOARD
% * Output parameters :
%    error_code [int32]         zero on success, nonzero indicates failure,
%                               returned value is the SDK errorcode
%
% date: 03.2003 / written by S. Zhao, The Cooke Corporation,
% www.cookecorp.com
% revision history:
% 2005 March - first release
% 2005 March - added help comments GHo, PCO AG
% 2008 June - switch to work with handles MBL PCO AG
% 2014 September - pf_cam SDK, no unload MBL PCO AG

if not(libisloaded('PCO_PF_SDK'))
 error('library must have been loaded with pfINITBOARD')
end

if nargin ~= 1
 error('...wrong number of arguments have been passed to pfCLOSEBOARD, see help!')
end

error_code = calllib('PCO_PF_SDK', 'CLOSEBOARD', board_handle);

end

