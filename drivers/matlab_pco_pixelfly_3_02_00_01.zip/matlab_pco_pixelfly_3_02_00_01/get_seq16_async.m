function [image_stack] = get_seq16_async(board_number,nr_of_images)
% grab multiple images with ADD_BUFFER,WAIT_FOR_BUFFER function. Camera mode ASYNC
%
% [error_code,image] = get_seq16_async(board_number,nr_of_images);
%
% get_seq16_async does grab 'nr_of_images' in ASYNC mode from the camera 
% to a Matlab image stack using allocate and wait functions from library
% 4 SDK buffer out of the stack are used with ADD_BUFFER and WAIT_FOR_BUFFER
% recorded imagestack can be displayed with function draw_images 
% or 'implay' from MATLAB image toolbox
%
% * Input parameters :
%    board_number               number of board to use [0...7] default 0
%    nr_of_images               number of images to grab
% * Output parameters :
%    image_stack [uint16(,,)]   image stack with grabbed images
%
% global glvar
% see glvar_init for more information for global structure glvar
%
% if global glvar is not initialized,
% the library is loaded at begin and unloaded at end
% the SDK is opened at begin and closed at end
%
% function workflow
% load library if not already loaded
% camera SDK is opened if not already open
% camera is prepared
% image stack is allocated
% camera recording is started
% grab images to image stack
% camera is stopped
% camera SDK is closed
% library is unloaded
%
% 2014 September - MBL PCO AG

 global glvar;

 pf_load_defines;
 
 [fh_prog_exit,fh_prog_init,fh_com_disp]=pf_misc_func();

 if(nargin<1)
  board_number=0;
 end 
 
 if(nargin<2)
  nr_of_images=10;   
 end

 if(nargout<1)
  error('Wrong number of output arguments. Need variable for image_stack');
 end 

 [do_unload,do_close,cam_open,board_handle,ret_bufnr,comment]=fh_prog_init(board_number);

%try to initialize camera
 if(cam_open==0)
  fh_com_disp(comment,['call pfINITBOARD(',int2str(board_number),') open driver and initialize camera']);
  [error_code,board_handle] = pfINITBOARD(board_number);
  if(error_code~=0) 
   pco_errdisp('pfINITBOARD',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   image_stack=0;
   return;
  end 
  fh_com_disp(comment,['Camera ',int2str(board_number),' opened']);
 end
 
 
 cam_open=1;
 if(~isempty(glvar))
  bnr=board_number+1;   
  if((isfield(glvar.boardpar(bnr),'camera_open'))&& ...
    (isfield(glvar.boardpar(bnr),'board_handle')))
   glvar.boardpar(bnr).camera_open=cam_open;
   glvar.boardpar(bnr).board_handle=board_handle; 
  end 
 end 
 
 [error_code, value] = pfGETBOARDVAL(board_handle,'PCC_VAL_BOARD_STATUS');
 if(error_code)
  pco_errdisp('pfGETBOARDVAL',error_code);    
 else
  if(bitand(value,hex2dec('01'))==hex2dec('01'))
   fh_com_disp(comment,'Camera is running call STOP_CAMERA')     
   error_code=pfSTOP_CAMERA(board_handle);
   pco_errdisp('pfSTOP_CAMERA',error_code);
  end 
 end

 fh_com_disp(comment,'call pfSETMODE, set mode ASYNC SW trigger, exposuretime=5ms ');
 fh_com_disp(comment,'                no horizontal and vertical binning, 12bit readout');

 mode=hex2dec('11');
 exptime=5000; 
 waittime_ms=exptime/1000+1000;
 error_code=pfSETMODE(board_handle,mode,50,exptime,0,0,0,0,12,0);
 if(error_code~=0) 
  pco_errdisp('pfSETMODE',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end 

 fh_com_disp(comment,'Camera setup done');
 fh_com_disp(comment,'call pfGETSIZES, to get actual resolution of the camera');

 [error_code,~,~,act_width,act_height,bit_pix]=pfGETSIZES(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfGETSIZES',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end

%get the memory for the images
 imasize=act_width*act_height*floor((bit_pix+7)/8);
 
 fh_com_disp(comment,['image size in bytes is: ',int2str(imasize)]); 
 fh_com_disp(comment,'allocate data array (image_stack) for the image');

 image_stack_i=ones(act_width,act_height,nr_of_images,'uint16');
 imaptr(nr_of_images)=libpointer;
 
 if(nr_of_images<4)
  add_buf=nr_of_images;  
 else 
  add_buf=4;  
 end 

 next_ima_nr=1;
 if(ret_bufnr(1)<0)
 ret_bufnr=zeros(add_buf,1,'int32');  
  for i=1:add_buf 
   ret_bufnr(i)=-1;   
  end 
 end 
 
 for i=1:add_buf 
  imaptr(next_ima_nr) = libpointer('uint16Ptr',image_stack_i(:,:,next_ima_nr));
  fh_com_disp(comment,'call pfALLOCATE_BUFFER_EX, to assign a buffer number to allocated image_stack');
  bufnr=ret_bufnr(i);
  [error_code,ret_bufnr(i)] = pfALLOCATE_BUFFER_EX(board_handle,bufnr,imasize,imaptr(next_ima_nr));
  if(error_code~=0) 
   pco_errdisp('pfALLOCATE_BUFFER_EX',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   return;
  end
  fh_com_disp(comment,['Buffer number ',int2str(ret_bufnr(i)),' assigned to allocated image_stack ',num2str(next_ima_nr)]);
     
  fh_com_disp(comment,'call pfADD_BUFFER_TO_LIST, to add buffer to the SDK buffer queue');
  error_code=pfADD_BUFFER_TO_LIST(board_handle,ret_bufnr(i),imasize);
  if(error_code~=0) 
   pco_errdisp('pfADD_BUFFER_TO_LIST',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   return;
  end
  fh_com_disp(comment,['Buffer number ',int2str(ret_bufnr(i)),' added to SDK buffer queue']);
 
  next_ima_nr=next_ima_nr+1;
 end 

 error_code=pfSTART_CAMERA(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfSTART_CAMERA',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,'Camera started');
 
 error_code=pfTRIGGER_CAMERA(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfTRIGGER_CAMERA',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,'Camera triggered first image');
 
 d=10;
 if(nr_of_images>50)
  if(nr_of_images<500)
   d=50;
  else
   d=100;
  end 
 end 

 fh_com_disp(comment,['begin grab loop of ',int2str(nr_of_images),' images']);

 comment1=0;
 if((nr_of_images<=10)&&(comment))
  comment1=1;
 end 
 
 for ima_nr=1:nr_of_images
  [error_code,bufnr,bufstat]=pfWAIT_FOR_BUFFERS(board_handle,waittime_ms,ret_bufnr);
  if(error_code~=0) 
   pco_errdisp('pfWAIT_FOR_BUFFERS',error_code);
   break;
  end

  error_code=pfTRIGGER_CAMERA(board_handle);
  if(error_code~=0) 
   pco_errdisp('pfTRIGGER_CAMERA',error_code);
   break;
  end
  fh_com_disp(comment1,'Camera triggered next image');
  
  [valid,~]=size(bufnr);
  for i=1:valid
   image_status=bitand(pco_uint32(bufstat(i)),hex2dec('F10F'));
   fh_com_disp(comment1,[num2str(bufnr(i)),': bitand buffer status is ',num2str(image_status,'%08X')]);
     
   if((bufnr(i)<0)||(image_status~=hex2dec('0002')))
    error_code=PCO_ERROR_APPLICATION+PCO_ERROR_WRONGVALUE;   
    disp('error: image not successfully grabbed');
    break;
   else
    image_stack_i(:,:,ima_nr)=get(imaptr(ima_nr),'Value');

    if(nr_of_images<=10)   
     m=max(max(image_stack_i(:,10:end,ima_nr)));
     fh_com_disp(comment1,[int2str(ima_nr),'. image grabbed max value ',int2str(m)]);
    else
     if(rem(ima_nr,d)==0)
      fh_com_disp(comment,[int2str(ima_nr),'. image grabbed']);
     end 
    end
    
    if((ima_nr+add_buf)<=nr_of_images)
     imaptr(next_ima_nr) = libpointer('uint16Ptr',image_stack_i(:,:,next_ima_nr));
     [error_code] = pfALLOCATE_BUFFER_EX(board_handle,bufnr(i),imasize,imaptr(next_ima_nr));
     if(error_code~=0) 
      pco_errdisp('pfALLOCATE_BUFFER_EX',error_code);
      break
     end
     fh_com_disp(comment1,['Buffer number ',int2str(bufnr(i)),' assigned to allocated image_stack ',num2str(next_ima_nr)]);
     
     error_code=pfADD_BUFFER_TO_LIST(board_handle,bufnr(i),imasize);
     if(error_code~=0) 
      pco_errdisp('pfADD_BUFFER_TO_LIST',error_code);
      break;
     end
     fh_com_disp(comment1,['Buffer number ',int2str(bufnr(i)),' added to SDK buffer queue']);
     next_ima_nr=next_ima_nr+1;
    end    
   end 
  end
  
  if(error_code~=0)
   break;  
  end
 end

 if(error_code==0)
  fh_com_disp(comment,[int2str(ima_nr),' images grabbed']);
 end 
%we can close our camera here 
 fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);

 if(error_code==0)
  image_stack=ones(act_height,act_width,nr_of_images,'uint16');
 
  for ima_nr=1:nr_of_images
   image_stack(:,:,ima_nr)=image_stack_i(:,:,ima_nr)';   
  end    
 else
  image_stack=zeros(act_height,act_width,1,'uint16');     
 end
 
 clear image_stack_i
end
  
