function [fh_prog_exit,fh_prog_init,fh_com_disp]=pf_misc_func()
%creating function handles to the following functions:
%prog_exit()
%unload()
%com_disp()

 if(strcmp(computer('arch'),'win32'))
  if(~exist('./pf_cam.dll','file'))
   copyfile('./win32/pf_cam.dll','./');
  end 
 elseif(strcmp(computer('arch'),'win64'))
  if(~exist('./pf_cam.dll','file'))
   copyfile('./x64/pf_cam.dll','./');
  end 
 else
  error('This platform is not supported');   
 end 

fh_prog_exit=@prog_exit;
fh_prog_init=@prog_init;
fh_com_disp=@com_disp;
end

function prog_exit(board_handle,do_close,do_unload,ret_bufnr)

 global glvar;
 comment=1; 
 if((~isempty(glvar))&&(isfield(glvar,'comment')))
  comment=glvar.comment;
 end  

 cam_open=0;

 if(~isempty(board_handle))
  cam_open=1;

  if(do_close)
   error_code=pfSTOP_CAMERA(board_handle);
   pco_errdisp('pfSTOP_CAMERA',error_code);

   [error_code]=pfREMOVE_ALL_BUFFERS_FROM_LIST(board_handle);
   pco_errdisp('pfREMOVE_BUFFER_FROM_LIST',error_code);
 
   [valid,~]=size(ret_bufnr);
   for i=1:valid
    if(ret_bufnr(i)>=0)
     error_code=pfFREE_BUFFER(board_handle,ret_bufnr(i));
     pco_errdisp('pfFREE_BUFFER',error_code);
    end 
   end 
   if(~isempty(glvar))
    for n=1:8   
     if(glvar.boardpar(n).board_handle==board_handle)
      if(isfield(glvar.boardpar(n),'buf_numbers'))
       glvar.boardpar(n).buf_numbers=-1;
      end
     end
    end 
   end
   
   error_code=pfCLOSEBOARD(board_handle);
   pco_errdisp('pfCLOSEBOARD',error_code);
   if(error_code==0) 
    com_disp(comment,'pfCLOSEBOARD done');
    cam_open=0;
    if(~isempty(glvar))
     for n=1:8   
      if((isfield(glvar.boardpar(n),'camera_open'))&& ...
         (isfield(glvar.boardpar(n),'board_handle')))
       if(glvar.boardpar(n).board_handle==board_handle)  
        glvar.boardpar(n).camera_open=cam_open;
        glvar.boardpar(n).board_handle=[]; 
       end
      end 
     end 
    end 
   end 
  end 
 end
 
 if(do_unload==1)
  unload_lib(cam_open)
 end 
end


function unload_lib(cam_open)
 global glvar;
 comment=1; 
 if((~isempty(glvar))&&(isfield(glvar,'comment')))
  comment=glvar.comment;
 end  
     
 open=cam_open;   
 for n=1:8
  if(~isempty(glvar))
   if((isfield(glvar.boardpar(n),'camera_open'))&& ...
      (isfield(glvar.boardpar(n),'board_handle')))
    if(glvar.boardpar(n).camera_open~=0)
     open=open|1;
     com_disp(comment,['open camera found at board: ',int2str(n-1)]);
    end 
   end 
  end  
 end   
 
 if(open==0)   
  if(libisloaded('PCO_PF_SDK'))
   unloadlibrary('PCO_PF_SDK');
   com_disp(comment,'PCO_PF_SDK unloadlibrary done');
  end
 end    
 
end   

function [do_unload,do_close,cam_open,board_handle,ret_bufnr,comment]=prog_init(board_number)
 global glvar;
 
 comment=1;
 
 if(isempty(glvar))
  do_unload=1;   
  do_close=1;
  cam_open=0;
  board_handle=[];
  ret_bufnr=int32(-1);
 else
  if(isfield(glvar,'do_libunload'))
   do_unload=glvar.do_libunload;    
  end
  if(isfield(glvar,'comment'))
   comment=glvar.comment;
  end  
  bnr=board_number+1;  
  if(isfield(glvar.boardpar(bnr),'do_close'))
   do_close=glvar.boardpar(bnr).do_close;    
  end
  if((isfield(glvar.boardpar(bnr),'camera_open'))&&(isfield(glvar.boardpar(bnr),'board_handle')))
   cam_open=glvar.boardpar(bnr).camera_open;
   board_handle=glvar.boardpar(bnr).board_handle; 
  end 
  if(isfield(glvar.boardpar(bnr),'buf_numbers'))
   ret_bufnr=glvar.boardpar(bnr).buf_numbers;
  end
 end  
end

function com_disp(comment,txt)
 if(comment)
  disp(txt);
 end 
end

