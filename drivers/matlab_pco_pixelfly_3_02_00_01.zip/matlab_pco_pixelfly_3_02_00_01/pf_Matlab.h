//-----------------------------------------------------------------//
// Name        | PfcamMatlab.h               | Type: ( ) source    //
//-------------------------------------------|       (*) header    //
// Project     | PCO                         |       ( ) others    //
//-----------------------------------------------------------------//
// Platform    | PC                                                //
//-----------------------------------------------------------------//
// Environment | Matlab                                            //
//-----------------------------------------------------------------//
// Purpose     | PCO - Matlab                                      //
//-----------------------------------------------------------------//
// Author      | MBL, PCO AG                                       //
//-----------------------------------------------------------------//
// Revision    |  rev. 3.01 rel. 3.01                              //
//-----------------------------------------------------------------//
// Notes       | Does include all necessary header files           //
//             |                                                   //
//             |                                                   //
//-----------------------------------------------------------------//
// (c) 2012 PCO AG * Donaupark 11 *                                //
// D-93309      Kelheim / Germany * Phone: +49 (0)9441 / 2005-0 *  //
// Fax: +49 (0)9441 / 2005-20 * Email: info@pco.de                 //
//-----------------------------------------------------------------//

#pragma pack(push)            
#pragma pack(1)            

#define MATLAB

#include "pco_matlab.h"

#include "pf_ML_struct.h"
#include "PfcamExport.h"



#define PCO_ERR_H_CREATE_OBJECT
#include "PCO_err.h"
#undef PCO_ERR_H_CREATE_OBJECT



#pragma pack(pop)            
