function draw_images1(data,wait,lim)
% draws image data to figure. Scale image for resolutions above 800x600 
%
% * Input parameters :
%    data [uint16(,,)]          image data array (height,width,count)
%    wait                       time to wait between images (optional) default: 0.01)
%    lim                        upper and lower limits to display (optional)
%                               default: [0 m], where m is maximal value calculated from first image   
%
% * Output parameters :

 if(nargin<1)
  error('Wrong number of input arguments. Need data array');
 end 

 if(nargin<2)
  wait=0.010;
 end 

 if(nargin<3)
  ulim=max(max(data(10:end-10,10:end-10,1)));
  lim=[0 ulim];  
 end 
  
 
 [~,~,count]=size(data);
 
 draw_image(data(:,:,1),lim);
 for ima_nr=1:count
  image(data(:,:,ima_nr),'CDataMapping','scaled');
  if(wait==0)
   disp('Press any key to proceed')
   pause
  else 
   pause(wait);
  end 
 end 
 disp('Press "Enter" to close window and proceed');
 pause();
 close();
 pause(1);
end
