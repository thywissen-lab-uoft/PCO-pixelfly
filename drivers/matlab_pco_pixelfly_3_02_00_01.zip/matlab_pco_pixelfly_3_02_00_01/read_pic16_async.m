function [error_code,ima] = read_pic16_async(board_number)
% grab single image with READ_IMAGE function. Camera mode ASYNC
%
% [error_code,image] = read_pic16_video(board_number);
%
% read_pic16_async does grab one image in ASYNC mode from the camera
% using read_image function from library
% image is displayed in image window, if no output variable is given
%
% * Input parameters :
%    board_number               number of board to use [0...7] default 0
% * Output parameters :
%    error_code                 returned error_code from SDK-functions 
%    image                      image data
%                               if not avaiable image is displayed with imshow() 
%
% global glvar
% see glvar_init for more information for global structure glvar
%
% if global glvar is not initialized,
% the library is loaded at begin and unloaded at end
% the SDK is opened at begin and closed at end
%
% function workflow
% load library if not already loaded
% camera SDK is opened if not already open
% camera is prepared
% image buffer is allocated
% camera recording is started
% grab image to image buffer
% camera is stopped
% camera SDK is closed
% library is unloaded
% image buffer is displayed or returned

% 2014 September - MBL PCO AG

 global glvar;
 
 pf_load_defines;
 
 [fh_prog_exit,fh_prog_init,fh_com_disp]=pf_misc_func();

 if(nargin<1)
  board_number=0;
 end 
 
 if(~exist('show_ima','var'))
  if(nargout<2)
   show_ima=1;   
  else 
   show_ima=0;   
   ima=0;   
  end 
 end 

 [do_unload,do_close,cam_open,board_handle,ret_bufnr,comment]=fh_prog_init(board_number);
 
%try to initialize camera
 if(cam_open==0)
  fh_com_disp(comment,['call pfINITBOARD(',int2str(board_number),') open driver and initialize camera']);
  [error_code,board_handle] = pfINITBOARD(board_number);
  if(error_code~=0) 
   pco_errdisp('pfINITBOARD',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   return;
  end 
  fh_com_disp(comment,['Camera ',int2str(board_number),' opened']);
 end
 
 
 cam_open=1;
 if(~isempty(glvar))
  bnr=board_number+1;   
  if((isfield(glvar.boardpar(bnr),'camera_open'))&& ...
    (isfield(glvar.boardpar(bnr),'board_handle')))
   glvar.boardpar(bnr).camera_open=cam_open;
   glvar.boardpar(bnr).board_handle=board_handle; 
  end 
 end 
 
 [error_code, value] = pfGETBOARDVAL(board_handle,'PCC_VAL_BOARD_STATUS');
 if(error_code)
  pco_errdisp('pfGETBOARDVAL',error_code);   
 else
  if(bitand(value,hex2dec('01'))==hex2dec('01'))
   fh_com_disp(comment,'Camera is running call STOP_CAMERA')     
   error_code=pfSTOP_CAMERA(board_handle);
   pco_errdisp('pfSTOP_CAMERA',error_code);
  end 
 end
 
 fh_com_disp(comment,'call pfSETMODE, set mode ASYNC SW trigger, exposuretime=5ms ');
 fh_com_disp(comment,'                no horizontal and vertical binning, 12bit readout');
 
 mode=hex2dec('11');
 exptime=5000; 
 waittime_ms=exptime/1000+1000;
 error_code=pfSETMODE(board_handle,mode,50,exptime,0,0,0,0,12,0);
 if(error_code~=0) 
  pco_errdisp('pfSETMODE',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end 

 fh_com_disp(comment,'Camera setup done');
 fh_com_disp(comment,'call pfGETSIZES, to get actual resolution of the camera');

 [error_code,~,~,act_width,act_height,bit_pix]=pfGETSIZES(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfGETSIZES',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end

%get the memory for the image
 imasize=act_width*act_height*floor((bit_pix+7)/8);

 fh_com_disp(comment,['image size in bytes is: ',int2str(imasize)]); 
 fh_com_disp(comment,'allocate data array (image_stack) for the image');
 
 image_stack=ones(act_width,act_height,'uint16');
 ima_ptr = libpointer('uint16Ptr',image_stack);

 error_code=pfSTART_CAMERA(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfSTART_CAMERA',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,'Camera started');

%now grab one image out of the video stream
%trigger is done internal
%timeout is exptime + 1 second
 [error_code]=pfREAD_IMAGE(board_handle,0,imasize,ima_ptr,waittime_ms);
 if(error_code~=0) 
  pco_errdisp('pfREAD_IMAGE',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end

 fh_com_disp(comment,'image grabbed to image_stack ');


 
 fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
 
 image_stack=get(ima_ptr,'Value');
 ima=image_stack';
 if(comment)
  m=max(max(ima(10:end-10,10:end-10)));
  disp(['maximum value in center of image is ',num2str(m)]);
 end 

 if(show_ima)
  m=max(max(ima(10:end-10,10:end-10)));
%  imshow(ima,[0,m+100]);
  draw_image(ima,[0 m+100]);
  disp('Press "Enter" to close window and proceed');
  pause();
  close();
  pause(1);
  clear ima;
 end
end

