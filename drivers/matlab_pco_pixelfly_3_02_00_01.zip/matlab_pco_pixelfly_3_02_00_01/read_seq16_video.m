function [image_stack] = read_seq16_video(board_number,nr_of_images)
% grab multiple images with READ_IMAGE function. Camera mode VIDEO
%
% [error_code,image] = read_seq16_video(board_number,nr_of_images);
%
% read_seq16_video does grab 'nr_of_images' in VIDEO mode from the camera 
% to a Matlab image stack using read_image function from library
% this function might not be fast enough to follow the image stream from the camera
% and therefore some images may be dropped
% recorded imagestack can be displayed with function draw_images 
% or 'implay' from MATLAB image toolbox
%
% * Input parameters :
%    board_number               number of board to use [0...7] default 0
%    nr_of_images               number of images to grab
% * Output parameters :
%    image_stack [uint16(,,)]   image stack with grabbed images
%
% global glvar
% see glvar_init for more information for global structure glvar
%
% if global glvar is not initialized,
% the library is loaded at begin and unloaded at end
% the SDK is opened at begin and closed at end
%
% function workflow
% load library if not already loaded
% camera SDK is opened if not already open
% camera is prepared
% image stack is allocated
% camera recording is started
% grab images to image stack
% camera is stopped
% camera SDK is closed
% library is unloaded
%
% 2014 September - MBL PCO AG

 global glvar;

 pf_load_defines;
 
 [fh_prog_exit,fh_prog_init,fh_com_disp]=pf_misc_func();

 if(nargin<1)
  board_number=0;
 end 
 
 if(nargin<2)
  nr_of_images=10;   
 end

 if(nargout<1)
  error('Wrong number of output arguments. Need variable for image_stack');
 end 

 [do_unload,do_close,cam_open,board_handle,ret_bufnr,comment]=fh_prog_init(board_number);

%try to initialize camera
 if(cam_open==0)
  fh_com_disp(comment,['call pfINITBOARD(',int2str(board_number),') open driver and initialize camera']);
  [error_code,board_handle] = pfINITBOARD(board_number);
  if(error_code~=0) 
   pco_errdisp('pfINITBOARD',error_code);
   fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
   image_stack=0;
   return;
  end 
  fh_com_disp(comment,['Camera ',int2str(board_number),' opened']);
 end
 
 
 cam_open=1;
 if(~isempty(glvar))
  bnr=board_number+1;   
  if((isfield(glvar.boardpar(bnr),'camera_open'))&& ...
    (isfield(glvar.boardpar(bnr),'board_handle')))
   glvar.boardpar(bnr).camera_open=cam_open;
   glvar.boardpar(bnr).board_handle=board_handle; 
  end 
 end 
 
 [error_code, value] = pfGETBOARDVAL(board_handle,'PCC_VAL_BOARD_STATUS');
 if(error_code)
  pco_errdisp('pfGETBOARDVAL',error_code);    
 else
  if(bitand(value,hex2dec('01'))==hex2dec('01'))
   fh_com_disp(comment,'Camera is running call STOP_CAMERA')     
   error_code=pfSTOP_CAMERA(board_handle);
   pco_errdisp('pfSTOP_CAMERA',error_code);
  end 
 end

 fh_com_disp(comment,'call pfSETMODE, set mode VIDEO SW trigger, exposuretime=5ms ');
 fh_com_disp(comment,'                no horizontal and vertical binning, 12bit readout');

 mode=hex2dec('31');
 exptime=5; 
 waittime_ms=exptime+1000;
 error_code=pfSETMODE(board_handle,mode,50,exptime,0,0,0,0,12,0);
 if(error_code~=0) 
  pco_errdisp('pfSETMODE',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end 

 fh_com_disp(comment,'Camera setup done');
 fh_com_disp(comment,'call pfGETSIZES, to get actual resolution of the camera');

 [error_code,~,~,act_width,act_height,bit_pix]=pfGETSIZES(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfGETSIZES',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end

%get the memory for the images
 imasize=act_width*act_height*floor((bit_pix+7)/8);
 
 fh_com_disp(comment,['image size in bytes is: ',int2str(imasize)]); 
 fh_com_disp(comment,'allocate data array (image_stack) for the image');

 image_stack_i=ones(act_width,act_height,nr_of_images,'uint16');
  
 error_code=pfSTART_CAMERA(board_handle);
 if(error_code~=0) 
  pco_errdisp('pfSTART_CAMERA',error_code);
  fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
  return;
 end
 fh_com_disp(comment,'Camera started');
 
 d=10;
 if(nr_of_images>50)
  if(nr_of_images<500)      
   d=50;
  else
   d=100;
  end 
 end 

 fh_com_disp(comment,['begin grab loop of ',int2str(nr_of_images),' images']);
 
 for ima_nr=1:nr_of_images
  ima_ptr = libpointer('uint16Ptr',image_stack_i(:,:,ima_nr));

  [error_code]=pfREAD_IMAGE(board_handle,0,imasize,ima_ptr,waittime_ms);
  if(error_code~=0) 
   pco_errdisp('pfREAD_IMAGE',error_code);
   break;
  end 
  
  image_stack_i(:,:,ima_nr)=get(ima_ptr,'Value');
  if(nr_of_images<=10)   
   m=max(max(image_stack_i(:,10:end,ima_nr)));
   fh_com_disp(comment,[int2str(ima_nr),'. image grabbed max value ',int2str(m)]);
  else
   if(rem(ima_nr,d)==0)
    fh_com_disp(comment,[int2str(ima_nr),'. image grabbed']);
   end 
  end
 end

 if(error_code==0)
  fh_com_disp(comment,[int2str(ima_nr),' images grabbed']);
 end 
%we can close our camera here 
 fh_prog_exit(board_handle,do_close,do_unload,ret_bufnr);
 
 if(error_code==0)
  image_stack=ones(act_height,act_width,nr_of_images,'uint16');
 
  for ima_nr=1:nr_of_images
   image_stack(:,:,ima_nr)=image_stack_i(:,:,ima_nr)';   
  end    
 else
  image_stack=zeros(act_height,act_width,1,'uint16');     
 end

 clear image_stack_i
end
  
