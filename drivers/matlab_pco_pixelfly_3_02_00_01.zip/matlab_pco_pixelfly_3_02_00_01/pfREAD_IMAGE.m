function [error_code, result_image] = pfREAD_IMAGE(board_handle,mode,ima_size,ima_ptr,timeout)
% pfREAD_IMAGE does a single image read from the camera to the
%
% [error_code, result_image] = pfREAD_IMAGE(board_handle,mode,ima_size,ima_ptr,timeout)
%
% pfREAD_IMAGE does a single image read from the camera to the
% address of an external allocated buffer with size ima_size.
% The allocated buffer must be greater than the imagesize resulting from
% the actual settings.
% Camera must have been started before.
% If Software Trigger is set, a Trigger command is sent to the camera
% Some postprocessing can be done on the image 
%
% * Input parameters :
%    board_handle [libpointer]  board_handle from INITBOARD
%    mode [int32]               postprocessing
%                                 0x00 none
%                                 0x01 flip image (vertical)
%                                 0x08 mirror image (horizontal)
%                                 0x09 flip and mirror image
%    bufsize [int32]            size of external allocated buffer    
%    ima_ptr [libpointer]       address of external allocated buffer                    
%    timeout                    time to wait for an image in ms   
%
% * Output parameters :
%    error_code [int32]         zero on success, nonzero indicates failure
%                               returned value is the SDK errorcode
%    result_image               Matlab array of either [uint8] or [uint16]
%                       
%          
% The camera only produces either 8 bit pixels or 12 bit. 
% A 12 bitperpixel occupies 16 bits (two bytes)
% When the sensor is colored, color information can be extracted from the 
% 12 bit data array in post-acquisition processing. 
%
% 2012 November - new pf_cam SDK (64Bit) MBL PCO AG

% check if library has been already loaded
if not(libisloaded('PCO_PF_SDK'))
 error('library must have been loaded with pfINITBOARD')
end

if nargin ~= 5
 error('...wrong number of arguments have been passed to pfREAD_IMAGE, see help!')
end

error_code =calllib('PCO_PF_SDK','READ_IMAGE',board_handle,mode,ima_size,ima_ptr,timeout);
if(error_code==0)
 result_image=get(ima_ptr,'Value');      
end 
end
