function [error_code,bufnrs_a,bufstat_a] = pfWAIT_FOR_BUFFERS(board_handle,waittime,bufnrs)
% pfWAIT_FOR_BUFFERS waits until one or more buffers have valid image data.
%
% [error_code] = pfWAIT_FOR_BUFFERS(board_number,varargin);                                             
%
% * Input parameters :
%    board_handle [libpointer]  board_handle from INITBOARD
%    waittime [int32]           time to wait for the image in ms
%    bufnrs [int32]             array of valid buffer numbers 
% * Output parameters :
%    error_code [int32]         zero on success, nonzero indicates failure
%                               returned value is the SDK errorcode
%    bufnrs_a [int32]           array of buffer numbers of buffers, which have valid image data 
%    bufstat_a [uint32]         array of BufferStatus values of buffers, which have valid image data 
% 
% 2008 June - MBL PCO AG
% 2012 November - new pf_cam SDK (64Bit) MBL PCO AG
% 2014 September - changed structure handling MBL PCO AG

% check if library has been already loaded
if not(libisloaded('PCO_PF_SDK'))
 error('library must have been loaded with pfINITBOARD')
end

if nargin ~= 3
 error('...wrong number of arguments have been passed to pfWAIT_FOR_BUFFER, see help!')
end

bufnrs_a=int32(-1);
bufstat_a=uint32(0);

[nr_of_buffer,~] = size(bufnrs);
if(nr_of_buffer>4)
 disp(['nr_of_buffer changed from' int2str(nr_of_buffer) 'to 4']);
 nr_of_buffer=4;   
end 

bl_m = libstruct('PCC_Buflist_m');
bl_m.bl1=libstruct('PCC_Buflist_s');
bl_m.bl2=libstruct('PCC_Buflist_s');
bl_m.bl3=libstruct('PCC_Buflist_s');
bl_m.bl4=libstruct('PCC_Buflist_s');

if(nr_of_buffer>3)
 bl_m.bl4.bufnr=int32(bufnrs(4));
 bl_m.bl4.BufferStatus=1;
end 
if(nr_of_buffer>2)
 bl_m.bl3.bufnr=int32(bufnrs(3));
 bl_m.bl3.BufferStatus=1;
end 
if(nr_of_buffer>1)
 bl_m.bl2.bufnr=int32(bufnrs(2));
 bl_m.bl2.BufferStatus=1;
end 
bl_m.bl1.bufnr=int32(bufnrs(1));
bl_m.bl1.BufferStatus=1;

error_code= calllib('PCO_PF_SDK','PCC_WAITFORBUFFER',board_handle,nr_of_buffer,bl_m,waittime);

if(error_code)
 pco_errdisp('PCC_WAITFORBUFFER',error_code);   
 return
end

valid_buffer=0;
for n=1:4
 s=bl_m.(strcat('bl',num2str(n)));
 image_status=bitand(pco_uint32(s.BufferStatus),hex2dec('F10F'));
 if(image_status==hex2dec('0002'))
  valid_buffer=valid_buffer+1;
 end
end 

if(nr_of_buffer==1)
 s=bl_m.(strcat('bl',num2str(1)));
 bufnrs_a=int32(s.bufnr);
 bufstat_a=pco_uint32(s.BufferStatus);
 return;
end

bufnrs_a=zeros(valid_buffer,1,'int32');
bufstat_a=zeros(valid_buffer,1,'uint32');

b=1;
for n=1:4
 s=bl_m.(strcat('bl',num2str(n)));
 image_status=bitand(pco_uint32(s.BufferStatus),hex2dec('F10F'));
 if(image_status==hex2dec('0002'))
  bufnrs_a(b)=s.bufnr;
  bufstat_a(b)=pco_uint32(s.BufferStatus);
  b=b+1;
 end 
end

