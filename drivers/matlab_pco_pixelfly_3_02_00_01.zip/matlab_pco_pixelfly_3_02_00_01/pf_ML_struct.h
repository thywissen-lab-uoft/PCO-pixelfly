#ifndef PCC_STRUCT_H
#define PCC_STRUCT_H


#define PCC_Buflist void
#define PCC_Buflist_a void

typedef struct                         // Buffer list structure for  PCO_WaitforBuffer
{
 int bufnr;
 unsigned int BufferStatus;
 unsigned int counter; //not used 
 HANDLE hBufferEvent;
}PCC_Buflist_s;

typedef struct                         // Buffer list structure for  PCO_WaitforBuffer
{
 PCC_Buflist_s bl1;
 PCC_Buflist_s bl2;
 PCC_Buflist_s bl3;
 PCC_Buflist_s bl4;
}PCC_Buflist_m;


typedef struct                         // Buffer list structure for  PCO_WaitforBuffer
{
 PCC_Buflist_s* p_bl1;
 PCC_Buflist_s* p_bl2;
 PCC_Buflist_s* p_bl3;
 PCC_Buflist_s* p_bl4;
}PCC_Buflist_p;

#endif

