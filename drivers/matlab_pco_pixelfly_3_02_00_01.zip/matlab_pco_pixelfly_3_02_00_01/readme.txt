//-----------------------------------------------------------------//
// Name        | readme.txt                  | Type: ( ) source    //
//-------------------------------------------|       ( ) header    //
// Project     | Matlab pco pixelfly         |       (*) others    //
//-----------------------------------------------------------------//
// Platform    | INTEL PC                                          //
//-----------------------------------------------------------------//
// Environment | Matlab 2011                                       //
//-----------------------------------------------------------------//
// Purpose     | instructions for use                              //
//-----------------------------------------------------------------//
// Author      | MBL, PCO AG                                       //
//-----------------------------------------------------------------//
// Revision    | 3,2,0,1                                           //
//-----------------------------------------------------------------//
// Notes       |                                                   //
//             |                                                   //
//             |                                                   //
//             |                                                   //
//-----------------------------------------------------------------//
// (c) 2014 PCO AG * Donaupark 11 *                                //
// D-93309      Kelheim / Germany * Phone: +49 (0)9441 / 2005-0 *  //
// Fax: +49 (0)9441 / 2005-20 * Email: info@pco.de                 //
//-----------------------------------------------------------------//


The Matlab pco_pixelfly project is a collection of example m-files and
additional header files.

With these m-files the setup of the camera can be done and
there are functions to grab and readout images to an Matlab imagestack. 

Only a subset of all possible camera settings is done in the examples.
For further setup see the SDK description.
In general
 all m-files with preamble 'pf' are matlab equivalents to distinct SDK-functions.

 all m-files with preamble 'pf_'   are example sequences, which call other m-files
                                   or do special tasks  

 all m-files with preamble 'get_'  are image capture examples which use ADD_BUFFER_TO_LIST
                                   and WAIT_FOR_BUFFERS functions of the SDK

 all m-files with preamble 'read_' are image capture examples which use READ_IMAGE
                                   function of the SDK

 all m-files with preamble 'draw_'  are image display functions

 all m-files with preamble 'pco_'   do specific data conversion needed for the 
                                    error codes returned from the SDK functions


To run the examples copy and unzip the matlab archiv in a distinct install directory.

For a simple test call camera_info.m m-file 
'pf_camera_info();'
This should output some messages about connected cameras type and revisions.


In most examples a global structure can be used, which does hold some information
about the current status of the library and can be use to control the behaviour of the
other m-files. To create and use this global structure call glvar_init.m


To test single image grab functions use
'get_pic16_video();' 
or
'read_pic16_video();' 

or without image display
'[err,ima]=get_pic16_video();' 
or
'[err,ima]=read_pic16_video();' 

To test sequence image grab functions use
'[imas]=get_seq16_video();' 
or
'[imas]=read_seq16_video();' 

All these functions call the following sequence before grabbing
pfINITBOARD
pfSTOP_CAMERA (if necessary)
pfSETUP_CAMERA
to set the camera to a known state.

Use either draw_xxx functions or functions from the Matlab image toolbox to display the single
image or the image sequences.
i.E.:
'imshow(ima,[0 1000]);'
'implay(imas);'
'draw_image(ima,[0 1000]);'
'draw_images(imas,[0 1000]);'


'get_camera_live();'
'read_camera_live();'
do live grabbing into a single image and display the images in an image window

Grabbing time can be given in the command line
'read_camera_live(0,5);'
is live grabbing for 5 seconds.

maximum number of images can be given in the command line
'read_camera_live(0,60,100);'
does live grabbing 100 images

All example code was tested with Matlab2011 64Bit and Matlab2010 32Bit Version.

When writing your own m-files it might happen that matlab does stop due to a syntax or other error.
Because then the camera is not closed correctly, the next run of the corrected m-file will fail.
To avoid this, best practice is to use global_structure and run 'pf_camera_open_close()',
which will return with error but does close the camera and unload the SC2_Cam-library.

  
Version 3.2.0.1:
- use pf_cam.dll 


KNOWN BUGS:
 none

