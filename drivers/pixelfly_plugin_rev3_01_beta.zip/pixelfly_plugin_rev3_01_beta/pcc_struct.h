//structure defines for pccam

/*
typedef struct
{
 int bufnr;
 unsigned int BufferStatus;
 unsigned int counter; //not used 
 HANDLE hBufferEvent;
}PCC_Buflist;

typedef struct
{
 int bufnr1;
 unsigned int BufferStatus1;
 unsigned int counter1; //not used 
 HANDLE hBufferEvent1;
}PCC_Buflist1;


typedef struct
{
 int bufnr1;
 unsigned int BufferStatus1;
 unsigned int counter1; //not used 
 HANDLE hBufferEvent1;
 int bufnr2;
 unsigned int BufferStatus2;
 unsigned int counter2; //not used 
 HANDLE hBufferEvent2;
}PCC_Buflist2;

typedef struct
{
 int bufnr1;
 unsigned int BufferStatus1;
 unsigned int counter1; //not used 
 HANDLE hBufferEvent1;
 int bufnr2;
 unsigned int BufferStatus2;
 unsigned int counter2; //not used 
 HANDLE hBufferEvent2;
 int bufnr3;
 unsigned int BufferStatus3;
 unsigned int counter3; //not used 
 HANDLE hBufferEvent3;
}PCC_Buflist3;
*/

typedef struct
{
 int bufnr1;
 unsigned int BufferStatus1;
 unsigned int counter1; //not used 
 HANDLE hBufferEvent1;
 int bufnr2;
 unsigned int BufferStatus2;
 unsigned int counter2; //not used 
 HANDLE hBufferEvent2;
 int bufnr3;
 unsigned int BufferStatus3;
 unsigned int counter3; //not used 
 HANDLE hBufferEvent3;
 int bufnr4;
 unsigned int BufferStatus4;
 unsigned int counter4; //not used 
 HANDLE hBufferEvent4;
}PCC_Buflist;
